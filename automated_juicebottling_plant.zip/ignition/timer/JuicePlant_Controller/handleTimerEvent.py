def handleTimerEvent():
	

    import system

    BASE = "[default]JuicePlant/"

    
    def read(p):
        v = system.tag.readBlocking([p])[0].value
        return v if v is not None else 0

    
    def write(p, v):
        system.tag.writeBlocking([p], [v])

    # READ TAGS 
    step  = read(BASE + "Simulation/ProcessStep")
    start = read(BASE + "Controls/Start")
    stop  = read(BASE + "Controls/Stop")
    estop = read(BASE + "Controls/EStop")

    water = read(BASE + "Process/WaterLevel")
    juice = read(BASE + "Process/JuiceLevel")


    # ALARM LOGIC (35%)

    lowWater = water < 35
    lowJuice = juice < 35

    write(BASE + "Alarms/LowWater", lowWater)
    write(BASE + "Alarms/LowJuice", lowJuice)


    # SAFETY LOGIC (20%)

    safe = (water > 20) and (juice > 20) and (not estop)
    write(BASE + "Controls/SafetyOK", safe)

    # AUTO E-STOP if unsafe
    if not safe:
        write(BASE + "Controls/EStop", True)
        write(BASE + "Controls/SystemRunning", False)
        write(BASE + "Simulation/ProcessStep", 0)


    # STEP 0 → IDLE

    if step == 0:

        write(BASE + "Equipment/Bottles/FillingActive", False)

        if start and safe:
            write(BASE + "Controls/SystemRunning", True)
            write(BASE + "Simulation/ProcessStep", 1)

    # STEP 1 → CHECK
    
    elif step == 1:

        if safe:
            write(BASE + "Simulation/ProcessStep", 2)
            write(BASE + "Simulation/MixTimer", 0)
        else:
            write(BASE + "Simulation/ProcessStep", 0)

 
    # STEP 2 → MIXING
   
    elif step == 2:

        t = read(BASE + "Simulation/MixTimer") + 1
        write(BASE + "Simulation/MixTimer", t)

        write(BASE + "Equipment/MixingTank/MixingActive", True)

        # Tank filling
        level = min(100, t * 10)
        write(BASE + "Equipment/MixingTank/Level", level)

        if t >= 10:
            write(BASE + "Equipment/MixingTank/MixingActive", False)
            write(BASE + "Equipment/MixingTank/MixingComplete", True)
            write(BASE + "Simulation/ProcessStep", 3)
            write(BASE + "Simulation/FillTimer", 0)

  
    # STEP 3 → FILLING
    
    elif step == 3:

        t = read(BASE + "Simulation/FillTimer") + 1
        write(BASE + "Simulation/FillTimer", t)

        count = read(BASE + "Equipment/Bottles/Count")
        level = read(BASE + "Equipment/MixingTank/Level")

        write(BASE + "Equipment/Bottles/FillingActive", True)

        if t >= 3:

            # Increase bottle count
            write(BASE + "Equipment/Bottles/Count", count + 1)

            # Reduce tank level
            newLevel = max(0, level - 10)
            write(BASE + "Equipment/MixingTank/Level", newLevel)

            # Reduce raw materials
            water = read(BASE + "Process/WaterLevel")
            juice = read(BASE + "Process/JuiceLevel")

            write(BASE + "Process/WaterLevel", max(0, water - 5))
            write(BASE + "Process/JuiceLevel", max(0, juice - 5))

            # Reset timer
            write(BASE + "Simulation/FillTimer", 0)

        # Stop when tank empty
        if level <= 0:
            write(BASE + "Equipment/Bottles/FillingActive", False)
            write(BASE + "Simulation/ProcessStep", 0)

    # STOP / ESTOP HANDLING
    
    if stop:
        write(BASE + "Controls/SystemRunning", False)
        write(BASE + "Simulation/ProcessStep", 0)

   
    # RESET BUTTON LOGIC
    
    if read(BASE + "Controls/Reset"):

        system.tag.writeBlocking([
            BASE + "Simulation/ProcessStep",
            BASE + "Equipment/Bottles/Count",
            BASE + "Equipment/MixingTank/Level",
            BASE + "Process/WaterLevel",
            BASE + "Process/JuiceLevel",
            BASE + "Controls/EStop"
        ], [
            0, 0, 0, 100, 100, False
        ])

        write(BASE + "Controls/Reset", False)

    
    # RESET START/STOP BUTTONS (IMPORTANT)
    
    write(BASE + "Controls/Start", False)
    write(BASE + "Controls/Stop", False)